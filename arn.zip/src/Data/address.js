export const address = {
    name:"NEW HEAVEN PROTOCOL",
    roadAve:"Kigali Nyarugenge Av 20",
    city:"KIGALI City,Rwanda",
    zipCode:250
}