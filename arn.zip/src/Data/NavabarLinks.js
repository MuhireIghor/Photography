export const navLinks = [
    {
        name:"Home",
        redirectUrl:" "
    },
    {
        name:"About",
        redirectUrl:"About"
    },
    {
        name:"Services",
        redirectUrl:"Services"
    },
    {
        name:"Portofolio",
        redirectUrl:"Portofolio"
    },
    {
        name:"Blog",
        redirectUrl:"Blog"
    },
    {
        name:"Contacts",
        redirectUrl:"Contact"
    },
]