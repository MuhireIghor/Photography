export const testimonials = [
    {
        name: "Kurt&Kyra",
        date: "August,2017",
        message: "You have a wedding coming up and it's time to sit down to write that congratulations card for the couple-to-be. If you're like most of us, you've probably been putting it off for a while because it can be pretty difficult to figure out what to write in a wedding card. When it comes to what you should say, it depends entirely on your relationship with the couple. For instance, wedding wishes for a friend will likely be less formal than wishes for someone you don't know very well. Ultimately, you want to write a card that conveys your best wishes for the happy couple, and you can use this as a guide to write that perfect wedding greeting."
    },
    {
        name: "Kurt2&Kyra2",
        date: "August,2017",
        message: "You have a wedding coming up and it's time to sit down to write that congratulations card for the couple-to-be. If you're like most of us, you've probably been putting it off for a while because it can be pretty difficult to figure out what to write in a wedding card. When it comes to what you should say, it depends entirely on your relationship with the couple. For instance, wedding wishes for a friend will likely be less formal than wishes for someone you don't know very well. Ultimately, you want to write a card that conveys your best wishes for the happy couple, and you can use this as a guide to write that perfect wedding greeting."
    },
    {
        name: "Kurt3&Kyra3",
        date: "August,2017",
        message: "You have a wedding coming up and it's time to sit down to write that congratulations card for the couple-to-be. If you're like most of us, you've probably been putting it off for a while because it can be pretty difficult to figure out what to write in a wedding card. When it comes to what you should say, it depends entirely on your relationship with the couple. For instance, wedding wishes for a friend will likely be less formal than wishes for someone you don't know very well. Ultimately, you want to write a card that conveys your best ."
    },
]