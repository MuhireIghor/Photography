export const images = [
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982614/WhatsApp_Image_2022-10-24_at_8.31_8_n2fkci.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982614/WhatsApp_Image_2022-10-24_at_8.31_11_rshtc1.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982614/WhatsApp_Image_2022-10-24_at_8.31_8_n2fkci.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982609/PartyDressing_gxe16e.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982609/feastDressing_kntzav.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982614/WhatsApp_Image_2022-10-24_at_8.31_11_rshtc1.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982614/WhatsApp_Image_2022-10-24_at_8.31_8_n2fkci.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982614/WhatsApp_Image_2022-10-24_at_8.31_8_n2fkci.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982609/feastDressing_kntzav.png',
    'https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982609/PartyDressing_gxe16e.png',

]