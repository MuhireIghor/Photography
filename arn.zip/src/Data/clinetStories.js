export const clientStories = [
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982612/PhotoEditing_xksyel.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982609/PartyDressing_gxe16e.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982610/nhnMenStaff_ba8hda.png"
    },
    {
        event:"Online Workshops",
        imgaeUrl:"https://res.cloudinary.com/dpk9zrwl2/image/upload/v1669982616/WhatsApp_Image_2022-10-24_at_8.31_9_tjldu3.png"
    },


]