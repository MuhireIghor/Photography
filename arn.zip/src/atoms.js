import { atom } from "recoil";
export const showModal = atom({
    key:"showModal",
    default:false
})